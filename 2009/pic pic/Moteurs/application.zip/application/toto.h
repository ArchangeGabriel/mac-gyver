extern unsigned char totol, totoh;

//extern unsigned char *ep1_OutBuffer, *ep2_InBuffer;
