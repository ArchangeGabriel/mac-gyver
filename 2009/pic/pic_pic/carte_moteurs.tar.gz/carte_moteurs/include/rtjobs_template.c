/*-------------------------------------------------------------------------
  rtjobs.c - Real Time jobs

             (c) 2006 Pierre Gaufillet <pierre.gaufillet@magic.fr> 

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
-------------------------------------------------------------------------*/

// TODO You have to copy and specialize this file for your application

#include <pic18fregs.h>
// TODO Add your includes

/******************************************************************/

void rt_base_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}
    
void rt_basex2_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex4_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex8_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex16_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex32_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex64_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex128_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex256_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex512_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex1024_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex2048_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex4096_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex8192_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex16384_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex32768_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}

void rt_basex65536_job(void) __naked
{
    // TODO Add here a call to your applicative function
    __asm
        return
    __endasm;
}
