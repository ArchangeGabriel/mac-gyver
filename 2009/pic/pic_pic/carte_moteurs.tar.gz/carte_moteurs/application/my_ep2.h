// my_ep2.h //


#ifndef MY_EP2_H_
#define MY_EP2_H_

//#include "config.h"

#include "usbconf.h"

void my_ep2_init(void);
void my_ep2_in(void);
void my_prepare_ep2_in(void);

#endif /*MY_EP2_H_*/
