#!/bin/bash
# $Id: usbmon.sh,v 1.1 2006/03/21 21:58:58 gaufille Exp $

cat /sys/kernel/debug/usbmon/2t

